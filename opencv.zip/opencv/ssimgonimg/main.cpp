#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include <iostream>

using namespace cv;
using namespace std;

int main( int argc, const char** argv )
{
     Mat img1 = imread("ss.jpg",CV_LOAD_IMAGE_UNCHANGED); 
     Mat img2 = imread("aa.jpg",CV_LOAD_IMAGE_UNCHANGED);
     Mat merged;

     
     if (img1.empty()&img2.empty()) 
         
     {
          cout << "Error : Image cannot be loaded..!!" << endl;
          
          return -1;
     }
        addWeighted( img1,0.5,img2,0.5,0,merged );  
//      add(img1,img2,merged);  
     imshow("original", img1); 
     imshow("original", img2);
     imshow("merged", merged);
    
     waitKey(0); 
     
     return 0;
}






