#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include"opencv2/objdetect.hpp"
#include <iostream>

using namespace cv;
using namespace std;

   
int main( int argc, const char** argv )
{
     Mat img = imread("ss.jpg",CV_WINDOW_AUTOSIZE); 
     
     Mat dist;
     
    if (img.empty()) 
         
     {
          cout << "Error : Image cannot be loaded..!!" << endl;
          
          return -1;
     }
     Mat gray_image;
 
     cvtColor(img, gray_image, CV_RGB2GRAY );
    
  equalizeHist(gray_image,dist);
     
  imshow("original image",img);  
  
  imshow("equalized", dist );
  
  imshow("gray_image", gray_image );
       
    waitKey(0);
    
    return 0;
}




  



  

 


  


 




