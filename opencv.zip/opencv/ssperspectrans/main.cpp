#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include <iostream>

using namespace cv;
using namespace std;

int main( int argc, const char** argv )
{
       Point2f imgQuad[4]; 
    // Output Quadilateral or World plane coordinates
    Point2f outputQuad[4];
         
    // Lambda Matrix
    Mat lambda( 2, 4, CV_32FC1 );
    //Input and Output Image;
    Mat img, output;
     
    //Load the image
    img = imread( "ss1.jpg", 1 );
    // Set the lambda matrix the same type and size as img
    lambda = Mat::zeros( img.rows, img.cols, img.type() );
 
    // The 4 points that select quadilateral on the img , from top-left in clockwise order
    // These four pts are the sides of the rect box used as img 
    imgQuad[0] = Point2f( -30,-60 );
    imgQuad[1] = Point2f( img.cols+50,-50);
    imgQuad[2] = Point2f( img.cols+100,img.rows+50);
    imgQuad[3] = Point2f( -50,img.rows+50  );  
    // The 4 points where the mapping is to be done , from top-left in clockwise order
    outputQuad[0] = Point2f( 0,0 );
    outputQuad[1] = Point2f( img.cols-1,0);
    outputQuad[2] = Point2f( img.cols-1,img.rows-1);
    outputQuad[3] = Point2f( 0,img.rows-1  );
 
    // Get the Perspective Transform Matrix i.e. lambda 
    lambda = getPerspectiveTransform( imgQuad, outputQuad );
    // Apply the Perspective Transform just found to the src image
    warpPerspective(img,output,lambda,output.size() );
 
    //Display img and output
    imshow("Input",img);
    imshow("Output",output);
     waitKey(0); 
     
     return 0;
}
