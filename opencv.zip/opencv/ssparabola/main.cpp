#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include <iostream>

using namespace cv;
using namespace std;
int main()
{
int width = 500;

float miny =-20, maxy = 20;

Mat image = Mat::zeros(width,width,CV_8UC3);

vector<Point2f> list_point(width);

for(int i = 0; i < width; i++)
{
   list_point[i].x = i;
   float real_y = miny + ((maxy-miny)*i)/width;
   list_point[i].y = real_y*real_y;
}
//Draw the curve
for(int i = 1; i < width; i++) line(image,list_point[i-1],list_point[i],Scalar(127,0,127));
imshow("image",image);
waitKey(0);
return 0;
}
