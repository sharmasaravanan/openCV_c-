#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include <iostream>

using namespace cv;
using namespace std;

int main( int argc, const char** argv )
{
     Mat img = imread("ss.jpg",CV_LOAD_IMAGE_UNCHANGED); 

     if (img.empty()) 
         
     {
          cout << "Error : Image cannot be loaded..!!" << endl;
          
          return -1;
     }
     vector<Mat> rgb;
     split(img,rgb);
     
     imshow("original", img); 
     
     imshow("b", rgb[0]);
     imshow("g", rgb[1]);
     imshow("r", rgb[2]);
     
     waitKey(0); 
     
     return 0;
}






