#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include <iostream>

using namespace cv;
using namespace std;

int main( int argc, const char** argv )
{
     Mat img = imread("bb.jpg",CV_LOAD_IMAGE_UNCHANGED); 
     
     Mat dist;   
    
     if (img.empty()) 
         
     {
          cout << "Error : Image cannot be loaded..!!" << endl;
          
          return -1;
     }
     
     distanceTransform(img,dist,CV_DIST_L2,CV_DIST_MASK_PRECISE ,NULL);
     
     imshow( "original image", img );
    
     imshow("distance", dist);
    
     waitKey(0);
    
     return 0;
}
      
  
    
   




