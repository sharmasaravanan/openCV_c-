#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include <iostream>

using namespace cv;
using namespace std;

int main( int argc, const char** argv )
{
     Mat img = imread("ss.jpg",CV_LOAD_IMAGE_UNCHANGED); 
     
     Mat dist;   
    
     if (img.empty()) 
         
     {
          cout << "Error : Image cannot be loaded..!!" << endl;
          
          return -1;
     }
     
     imshow( "original image", img );
    
     Point2f pc(img.cols/2., img.rows/2.);
     
     Mat r = getRotationMatrix2D(pc, 65, 1.0);

     warpAffine(img, dist, r, img.size()); // what size I should use?

    imshow("rotated image", dist);
    
         
     waitKey(0); 
     
     return 0;
}

  
    
   




