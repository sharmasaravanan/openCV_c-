#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include <iostream>

using namespace cv;
using namespace std;

int main( int argc, const char** argv )
{
     Mat img = imread("ss.jpg",CV_LOAD_IMAGE_UNCHANGED); 
          
    if (img.empty()) 
         
     {
          cout << "Error : Image cannot be loaded..!!" << endl;
          
          return -1;
     }
     
     Rect myroi(100,100,500,500);
     
     Mat img2 = img(myroi);
     
     imshow("original", img); 
     imshow("cropped", img2); 
         
     waitKey(0); 
     
     return 0;
}






