
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include <iostream>

using namespace cv;
using namespace std;int main()
{
    Mat image = Mat::zeros(500,500,CV_8UC3);
    line(image,Point(15,20),Point(100,20),Scalar(150,0,150),4,8);
    line(image,Point(15,20),Point(15,200),Scalar(150,0,150),4,8);
    line(image,Point(15,200),Point(100,200),Scalar(150,0,150),4,8);
    line(image,Point(100,200),Point(100,20),Scalar(150,0,150),4,8);
    
    imshow("line_drawing",image);
    
    waitKey(0); 
    
    return (0);
}