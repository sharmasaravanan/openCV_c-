#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include <iostream>

using namespace cv;
using namespace std;

int main( int argc, const char** argv )
{
     Mat img = imread("aa.jpg",CV_LOAD_IMAGE_UNCHANGED); 
     
    if (img.empty()) 
         
     {
          cout << "Error : Image cannot be loaded..!!" << endl;
          
          return -1;
     }
    
     floodFill(img,Point(200,200),Scalar(0,180,0),0,Scalar(),Scalar(),4);
        
    imshow( "original image", img );
    
    waitKey(0);
    
     return 0;
}
      
  
    
   




