#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include <iostream>

using namespace cv;
using namespace std;

int main( int argc, const char** argv )
{
     Mat img = imread("ss.jpg",CV_LOAD_IMAGE_UNCHANGED); 
     
     Mat dist1;   
    
     Mat dist2;
     
     if (img.empty()) 
         
     {
          cout << "Error : Image cannot be loaded..!!" << endl;
          
          return -1;
     }
     
    logPolar(img,dist1,CvPoint2D32f(img.cols/2,img.rows/2),120,CV_INTER_LINEAR+CV_WARP_FILL_OUTLIERS);
     
   linearPolar(dist1,dist2,CvPoint2D32f(img.cols/2,img.rows/2),120,CV_INTER_LINEAR+CV_WARP_FILL_OUTLIERS);
    
    imshow( "original image", img );
    
     imshow("linear_polar", dist2);
     
     imshow("log_polar", dist1);
    
     waitKey(0);
    
     return 0;
}
      
  
    
   




