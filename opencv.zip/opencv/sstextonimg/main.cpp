#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include <iostream>

using namespace cv;
using namespace std;

int main( int argc, const char** argv )
{
     Mat img = imread("ss.jpg",CV_LOAD_IMAGE_UNCHANGED); 
          
    if (img.empty()) 
         
     {
          cout << "Error : Image cannot be loaded..!!" << endl;
          
          return -1;
     }
     
    putText(img,"yes!i am done!!",cvPoint(15,70),FONT_HERSHEY_TRIPLEX,2,
            cvScalar(200,0,0),2);
     imshow("original", img); 
         
     waitKey(0); 
     
     return 0;
}






