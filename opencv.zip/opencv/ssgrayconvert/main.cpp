#include "opencv2/highgui/highgui.hpp"
#include <iostream>
#include "opencv2/imgproc.hpp"
using namespace cv;
using namespace std;

int main( int argc, char** argv )
{
 
 Mat image = imread( "ss.jpg");

 if( image.empty())
 {
   printf( " No image data \n " );
   return -1;
 }

 Mat gray_image;
 cvtColor(image, gray_image, CV_RGB2GRAY );
 imwrite("/Users/HubinoMac2/Documents/gray.jpg",gray_image);

 imshow( "original" , image );
 imshow( "Gray image", gray_image );

 waitKey(0);

 return 0;
}