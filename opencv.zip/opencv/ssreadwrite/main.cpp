#include "opencv2/highgui/highgui.hpp"
#include <iostream>

using namespace cv;
using namespace std;

int main( int argc, const char** argv )
{
     Mat img = imread("ss.jpg",CV_LOAD_IMAGE_UNCHANGED); 

     if (img.empty()) 
         
     {
          cout << "Error : Image cannot be loaded..!!" << endl;
          
          return -1;
     }
    
    imwrite( "/Users/HubinoMac2/Documents/ss_copy.jpg", img );

    imshow("MyWindow", img); 
    
    waitKey(0); 
     
     return 0;
}