#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include"opencv2/objdetect.hpp"
#include <iostream>

using namespace cv;
using namespace std;

   
int main( int argc, const char** argv )
{
     Mat img = imread("group1.jpg",CV_LOAD_IMAGE_UNCHANGED); 
     
    CascadeClassifier face_cascade;
    
    face_cascade.load("/Applications/opencv/data/haarcascades/haarcascade_frontalface_alt2.xml");
     
    if (img.empty()) 
         
     {
          cout << "Error : Image cannot be loaded..!!" << endl;
          
          return -1;
     }
    
    vector<Rect> faces;
    
    face_cascade.detectMultiScale( img, faces, 1.11,4,0,Size(40, 40));
    
     for( int i = 0; i < faces.size(); i++ )
    {
        Point center( faces[i].x + faces[i].width*0.5, faces[i].y + faces[i].height*0.5 );
        ellipse( img, center, Size( faces[i].width*0.5, faces[i].height*0.5), 0, 0, 360, Scalar( 0, 0, 255 ), 4, 8, 0 );
    }

     
    imshow( "detected image", img );
       
    waitKey(0);
    
    return 0;
}







