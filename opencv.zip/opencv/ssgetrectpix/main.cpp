#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include <iostream>

using namespace cv;
using namespace std;

int main( int argc, const char** argv )
{
     Mat img = imread("ss.jpg",CV_LOAD_IMAGE_UNCHANGED); 
     
     Mat dist1;   
    
    if (img.empty()) 
         
     {
          cout << "Error : Image cannot be loaded..!!" << endl;
          
          return -1;
     }
     
    getRectSubPix(img,Size(img.rows/2,img.cols),Point2f(img.rows/4,img.cols/2) ,dist1);
        
    imshow( "original image", img );
    
    imshow("rectsubpix", dist1);
    
    waitKey(0);
    
     return 0;
}
      
  
    
   




